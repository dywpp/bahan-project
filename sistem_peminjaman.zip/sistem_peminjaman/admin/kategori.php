<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

// TAMBAH KATEGORI
if(isset($_POST['tambah'])){
    $nama = $_POST['nama_kategori'];
    $kode = $_POST['kode_kategori'];
    if($nama && $kode){
        mysqli_query($koneksi,"INSERT INTO kategori (nama_kategori,kode_kategori) VALUES ('$nama','$kode')");
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    }
}

// EDIT KATEGORI
if(isset($_POST['edit'])){
    $id = $_POST['id_kategori'];
    $nama = $_POST['nama_kategori'];
    $kode = $_POST['kode_kategori'];
    mysqli_query($koneksi,"UPDATE kategori SET nama_kategori='$nama', kode_kategori='$kode' WHERE id_kategori='$id'");
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// HAPUS KATEGORI
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    mysqli_query($koneksi,"DELETE FROM kategori WHERE id_kategori='$id'");
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// AMBIL DATA
$kategori = mysqli_query($koneksi,"SELECT * FROM kategori ORDER BY id_kategori DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CRUD Kategori</title>
<style>
/* Reset & Base */
body{
    font-family:'Montserrat',sans-serif;
    background:#f5f2ec;
    color:#333;
    margin:0;
    display:flex;
}
.sidebar{
    width:220px;
    background:#4a3f35;
    color:#fff;
    min-height:100vh;
    padding:20px;
    display:flex;
    flex-direction:column;
    gap:10px;
}
.sidebar a{
    color:#fff;
    text-decoration:none;
    padding:10px 15px;
    border-radius:8px;
    display:block;
    transition:0.3s;
}
.sidebar a:hover{
    background:#a67c52;
}
.main{
    flex:1;
    padding:30px 40px;
}
h1{
    margin-bottom:20px;
    color:#4a3f35;
}
.panel{
    background:#fff;
    border-radius:15px;
    padding:20px;
    margin-bottom:30px;
    box-shadow:0 4px 12px rgba(0,0,0,0.08);
}
.btn{
    background:#5f8cff;
    color:#fff;
    border:none;
    padding:8px 14px;
    border-radius:8px;
    cursor:pointer;
    transition:0.3s;
}
.btn:hover{
    opacity:0.85;
}
table{
    width:100%;
    border-collapse:collapse;
}
th,td{
    padding:12px 15px;
    text-align:left;
}
th{
    background:#f0e6d2;
    color:#4a3f35;
}
tr:nth-child(even){
    background:#faf5f0;
}
tr:hover{
    background:#f0e6d2;
}
.act a{
    margin-right:6px;
    font-size:12px;
    padding:4px 8px;
    border-radius:6px;
    color:#fff;
    text-decoration:none;
}
.edit{background:#2a3a6a;}
.del{background:#3a1a1a;}
.form-grid{
    display:flex;
    gap:10px;
    margin-bottom:10px;
}
.form-grid input{
    flex:1;
    padding:8px;
    border-radius:6px;
    border:1px solid #ddd;
}
@media (max-width:768px){
    body{flex-direction:column;}
    .sidebar{width:100%;flex-direction:row;flex-wrap:wrap;justify-content:center;}
    .main{padding:20px;}
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Menu</h2>
    <a href="admin_crud_user.php">Data User</a>
    <a href="admin_crud_alat.php">Alat</a>
    <a href="kategori.php">Kategori</a>
    <a href="peminjaman.php">Peminjaman</a>
    <a href="admin_crud_pengembalian.php">Pengembalian</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">
    <h1>Kategori Barang</h1>

    <!-- FORM TAMBAH -->
    <div class="panel">
        <form method="post" class="form-grid">
            <input type="text" name="nama_kategori" placeholder="Nama Kategori" required>
            <input type="text" name="kode_kategori" placeholder="Kode Kategori" required>
            <button class="btn" name="tambah">+ Tambah</button>
        </form>
    </div>

    <!-- TABEL DATA -->
    <div class="panel">
        <table>
            <tr>
                <th>#</th>
                <th>Nama Kategori</th>
                <th>Kode</th>
                <th>Aksi</th>
            </tr>
            <?php $no=1; while($row=mysqli_fetch_assoc($kategori)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                <td><?= htmlspecialchars($row['kode_kategori']) ?></td>
                <td class="act">
                    <a href="#" class="edit" onclick="document.getElementById('edit<?= $row['id_kategori'] ?>').style.display='block'">Edit</a>
                    <a href="?hapus=<?= $row['id_kategori'] ?>" class="del" onclick="return confirm('Hapus kategori ini?')">Hapus</a>

                    <div id="edit<?= $row['id_kategori'] ?>" style="display:none;margin-top:6px;">
                        <form method="post" class="form-grid">
                            <input type="hidden" name="id_kategori" value="<?= $row['id_kategori'] ?>">
                            <input type="text" name="nama_kategori" value="<?= htmlspecialchars($row['nama_kategori']) ?>" required>
                            <input type="text" name="kode_kategori" value="<?= htmlspecialchars($row['kode_kategori']) ?>" required>
                            <button class="btn" name="edit">Simpan</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

</body>
</html>


