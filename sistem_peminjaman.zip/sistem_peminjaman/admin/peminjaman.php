<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page-1) * $limit;

$keyword = $_GET['q'] ?? '';

$q = mysqli_query($koneksi,"
  SELECT p.id_peminjaman, p.tgl_pinjam, p.status, u.nama
  FROM peminjaman p
  JOIN users u ON p.id_user=u.id_user
  WHERE u.nama LIKE '%$keyword%'
  ORDER BY p.id_peminjaman DESC
  LIMIT $start, $limit
");

$total_result = mysqli_query($koneksi,"
  SELECT COUNT(*) as total
  FROM peminjaman p
  JOIN users u ON p.id_user=u.id_user
  WHERE u.nama LIKE '%$keyword%'
");
$total = mysqli_fetch_assoc($total_result)['total'];
$pages = ceil($total / $limit);
?>

<!DOCTYPE html>
<html>
<head>
<title>Peminjaman</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{
 --bg:#f5f2ec; --panel:#fff; --card:#fff; --border:#ccc;
 --text:#333; --muted:#666; --accent:#5f8cff;
}
body{margin:0;font-family:'Montserrat',sans-serif;background:var(--bg);color:var(--text);}
.container{max-width:1200px;margin:auto;padding:20px;}
.sidebar{
    width:220px;background:#4a3f35;color:#fff;position:fixed;top:0;bottom:0;left:0;padding:20px;
}
.sidebar h2{margin-top:0;font-size:20px;}
.sidebar a{display:block;color:#fff;text-decoration:none;padding:10px;margin:5px 0;border-radius:6px;}
.sidebar a:hover{background:#5f8cff;}
.main{margin-left:240px;padding:20px;}
.panel{background:var(--panel);padding:20px;border-radius:12px;box-shadow:0 3px 8px rgba(0,0,0,0.1);}
table{width:100%;border-collapse:collapse;margin-top:10px;}
th,td{padding:12px;text-align:left;border-bottom:1px solid #ddd;}
th{background:#f0e6d2;color:#4a3f35;}
tr:hover{background:#f9f2e8;}
form input{padding:8px;border-radius:6px;border:1px solid #ccc;margin-right:6px;}
form button{padding:8px 12px;border:none;border-radius:6px;background:var(--accent);color:#fff;cursor:pointer;}
</style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Dashboard</h2>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="admin_crud_user.php">User</a>
    <a href="admin_crud_alat.php">Alat</a>
    <a href="kategori.php">Kategori</a>
    <a href="peminjaman.php">Peminjaman</a>
    <a href="admin_crud_pengembalian.php">Pengembalian</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">
<h1>Peminjaman</h1>

<!-- FORM CARI -->
<div class="panel">
<form method="GET" action="">
<input type="text" name="q" placeholder="Cari nama user" value="<?= htmlspecialchars($keyword) ?>">
<button type="submit">Cari</button>
</form>
</div>

<!-- TABEL -->
<div class="panel">
<table>
<tr>
<th>#</th>
<th>Peminjam</th>
<th>Tanggal Pinjam</th>
<th>Status</th>
</tr>
<?php $no = $start + 1; while($r = mysqli_fetch_assoc($q)): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= htmlspecialchars($r['nama']) ?></td>
<td><?= htmlspecialchars($r['tgl_pinjam'] ?? '-') ?></td>
<td><?= htmlspecialchars($r['status'] ?? '-') ?></td>
</tr>
<?php endwhile; ?>
</table>

<!-- PAGINASI -->
<div style="margin-top:10px;">
<?php for($i=1; $i<=$pages; $i++): ?>
    <a href="?page=<?= $i ?><?= ($keyword) ? '&q='.$keyword : '' ?>" style="margin-right:5px;"><?= $i ?></a>
<?php endfor; ?>
</div>

</div>
</body>
</html>
