<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['email'], $_POST['password'])){
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $koneksi->prepare("SELECT id_user, nama, password, role, status FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 1){
        $user = $result->fetch_assoc();
        
        if($user['status'] != 'aktif'){
            $_SESSION['msg'] = "Akun tidak aktif!";
            header("Location: login.php");
            exit;
        }

        if(password_verify($password, $user['password'])){
            // set session
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['role'] = $user['role'];

            // redirect sesuai role
            if($user['role']=='admin'){
                header("Location: ../dashboard/admin.php");
            } elseif($user['role']=='petugas'){
                header("Location: ../dashboard/petugas.php");
            } else {
                header("Location: ../dashboard/user.php");
            }
            exit;
        } else {
            $_SESSION['msg'] = "Password salah!";
            header("Location: login.php");
            exit;
        }
    } else {
        $_SESSION['msg'] = "Email tidak terdaftar!";
        header("Location: login.php");
        exit;
    }
} else {
    $_SESSION['msg'] = "Form tidak lengkap!";
    header("Location: login.php");
    exit;
}
