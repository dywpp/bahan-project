<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);

if(!isset($_SESSION['otp_email'])){
    $_SESSION['msg'] = "Akses ditolak!";
    header("Location: forgot.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Masukkan OTP lalu buat password baru.</small>
    </div>
  </div>
  <h1 class="page-title">Reset Password</h1>
  <p class="page-subtitle">Selesaikan langkah reset agar akun Anda dapat digunakan kembali.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_reset.php">
    <div class="form-group">
      <input class="input" type="text" name="otp" placeholder="Masukkan OTP" required>
    </div>
    <div class="form-group">
      <input class="input" type="password" name="password" placeholder="Password Baru" required>
    </div>
    <div class="form-actions">
      <button class="button button-primary" type="submit">Reset Password</button>
    </div>
    <div class="form-footer">
      <a href="login.php">Kembali ke Login</a>
    </div>
  </form>
</div>
</body>
</html>
