<?php
session_start();
include "../config/koneksi.php";
require_once "../config/mailer.php"; // fungsi kirim email

if(isset($_POST['email'])){
    $email = $_POST['email'];

    // cek email di DB
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=? AND role='petugas'");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        // generate OTP 6 digit
        $otp = random_int(100000,999999);
        $_SESSION['otp_petugas'] = $otp;
        $_SESSION['otp_email_petugas'] = $email;
        $_SESSION['otp_time_petugas'] = time();

        sendOTP($email,$otp); // kirim OTP ke email
        $_SESSION['msg'] = "Kode OTP sudah dikirim ke email.";
        header("Location: verify_petugas.php");
        exit;
    } else {
        $_SESSION['msg'] = "Email tidak terdaftar!";
        header("Location: forgot_petugas.php");
        exit;
    }
}
