<?php
session_start();
include "../config/koneksi.php";
require_once "../config/mailer.php";

if(isset($_POST['otp'], $_POST['password'])){
    if(!isset($_SESSION['otp_petugas'], $_SESSION['otp_email_petugas'], $_SESSION['otp_time_petugas'])){
        $_SESSION['msg'] = "OTP tidak valid!";
        header("Location: forgot_petugas.php");
        exit;
    }

    if($_POST['otp'] != $_SESSION['otp_petugas'] || (time() - $_SESSION['otp_time_petugas']) > 300){
        $_SESSION['msg'] = "OTP salah atau kadaluarsa!";
        header("Location: forgot_petugas.php");
        exit;
    }

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_SESSION['otp_email_petugas'];

    $stmt = $koneksi->prepare("UPDATE users SET password=? WHERE email=? AND role='petugas'");
    $stmt->bind_param("ss", $password, $email);
    if($stmt->execute()){
        session_unset();
        $_SESSION['msg'] = "Password berhasil diubah, silakan login!";
        header("Location: login_petugas.php");
        exit;
    } else {
        $_SESSION['msg'] = "Terjadi kesalahan: ".$stmt->error;
        header("Location: forgot_petugas.php");
        exit;
    }
} elseif(isset($_POST['email'])){
    $email = trim($_POST['email']);

    // cek email
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=? AND role='petugas'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows == 0){
        $_SESSION['msg'] = "Email tidak terdaftar!";
        header("Location: forgot_petugas.php");
        exit;
    }

    // buat OTP
    $otp = random_int(100000, 999999);
    $_SESSION['otp_petugas'] = $otp;
    $_SESSION['otp_email_petugas'] = $email;
    $_SESSION['otp_time_petugas'] = time();

    sendOTP($email, $otp); // function dari mailer.php

    $_SESSION['msg'] = "Kode OTP sudah dikirim ke email Anda!";
    header("Location: forgot_petugas.php");
    exit;
} else {
    $_SESSION['msg'] = "Form tidak lengkap!";
    header("Location: forgot_petugas.php");
}
?>
