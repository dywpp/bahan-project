<?php
session_start();

if(isset($_POST['otp'])){
    if(!isset($_SESSION['otp_petugas'])){
        $_SESSION['msg'] = "Silakan request OTP terlebih dahulu.";
        header("Location: forgot_petugas.php");
        exit;
    }

    $otp_input = $_POST['otp'];
    $otp_session = $_SESSION['otp_petugas'];
    $otp_time = $_SESSION['otp_time_petugas'];

    if($otp_input == $otp_session && (time() - $otp_time) < 300){
        $_SESSION['step_reset_petugas'] = true;
        header("Location: reset_petugas.php");
        exit;
    } else {
        $_SESSION['msg'] = "OTP salah atau kadaluarsa!";
        header("Location: verify_petugas.php");
        exit;
    }
}
