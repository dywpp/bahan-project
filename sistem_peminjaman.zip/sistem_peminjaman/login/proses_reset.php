<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
include "../config/koneksi.php";

if(isset($_POST['otp'], $_POST['password'])){
    if(!isset($_SESSION['otp'], $_SESSION['otp_email'], $_SESSION['otp_time'])){
        $_SESSION['msg'] = "OTP tidak valid!";
        header("Location: forgot.php");
        exit;
    }

    if($_POST['otp'] != $_SESSION['otp'] || (time() - $_SESSION['otp_time']) > 300){
        $_SESSION['msg'] = "OTP salah atau kadaluarsa!";
        header("Location: reset_password.php");
        exit;
    }

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_SESSION['otp_email'];

    $stmt = $koneksi->prepare("UPDATE users SET password=? WHERE email=?");
    $stmt->bind_param("ss", $password, $email);
    if($stmt->execute()){
        session_unset();
        $_SESSION['msg'] = "Password berhasil diubah, silakan login!";
        header("Location: login.php");
        exit;
    } else {
        $_SESSION['msg'] = "Terjadi kesalahan: ".$stmt->error;
        header("Location: reset_password.php");
        exit;
    }
} else {
    $_SESSION['msg'] = "Form tidak lengkap!";
    header("Location: reset_password.php");
}
