<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['nama'], $_POST['email'], $_POST['password'])){
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // cek email sudah ada
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0){
        $_SESSION['msg'] = "Email sudah terdaftar!";
        header("Location: register.php");
        exit;
    }

    $stmt->close();

    // insert user baru
    $stmt = $koneksi->prepare("INSERT INTO users (nama,email,password,role,status) VALUES (?, ?, ?, 'user', 'aktif')");
    $stmt->bind_param("sss", $nama, $email, $password);
    if($stmt->execute()){
        $_SESSION['msg'] = "Register berhasil, silakan login!";
        header("Location: login.php");
    } else {
        $_SESSION['msg'] = "Terjadi kesalahan: ".$stmt->error;
        header("Location: register.php");
    }
    $stmt->close();
} else {
    $_SESSION['msg'] = "Form tidak lengkap!";
    header("Location: register.php");
}
