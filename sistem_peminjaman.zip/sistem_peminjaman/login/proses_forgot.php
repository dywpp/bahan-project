<?php
session_start();
include "../config/koneksi.php";
require_once "../config/mailer.php";

if(isset($_POST['otp'], $_POST['password'])){
    if(!isset($_SESSION['otp'], $_SESSION['otp_email'], $_SESSION['otp_time'])){
        $_SESSION['msg'] = "OTP tidak valid!";
        header("Location: forgot.php");
        exit;
    }

    if($_POST['otp'] != $_SESSION['otp'] || (time() - $_SESSION['otp_time']) > 300){
        $_SESSION['msg'] = "OTP salah atau kadaluarsa!";
        header("Location: forgot.php");
        exit;
    }

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_SESSION['otp_email'];

    $stmt = $koneksi->prepare("UPDATE users SET password=? WHERE email=?");
    $stmt->bind_param("ss", $password, $email);
    if($stmt->execute()){
        session_unset();
        $_SESSION['msg'] = "Password berhasil diubah, silakan login!";
        header("Location: login.php");
        exit;
    } else {
        $_SESSION['msg'] = "Terjadi kesalahan: ".$stmt->error;
        header("Location: forgot.php");
        exit;
    }
} elseif(isset($_POST['email'])){
    $email = trim($_POST['email']);

    // cek email
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows == 0){
        $_SESSION['msg'] = "Email tidak terdaftar!";
        header("Location: forgot.php");
        exit;
    }

    // buat OTP
    $otp = random_int(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_email'] = $email;
    $_SESSION['otp_time'] = time();

    sendOTP($email, $otp); // function dari mailer.php

    $_SESSION['msg'] = "Kode OTP sudah dikirim ke email Anda!";
    header("Location: forgot.php");
    exit;
} else {
    $_SESSION['msg'] = "Form tidak lengkap!";
    header("Location: forgot.php");
}
