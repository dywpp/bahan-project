<?php
session_start();
include "../config/koneksi.php";
require_once "../config/mailer.php";

if(isset($_POST['email'])){
    $email = trim($_POST['email']);

    // cek email
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows == 0){
        $_SESSION['msg'] = "Email tidak terdaftar!";
        header("Location: forgot.php");
        exit;
    }

    // buat OTP
    $otp = random_int(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_email'] = $email;
    $_SESSION['otp_time'] = time();

    sendOTP($email, $otp); // function dari mailer.php

    $_SESSION['msg'] = "Kode OTP sudah dikirim ke email Anda!";
    header("Location: reset_password.php");
    exit;
} else {
    $_SESSION['msg'] = "Form tidak lengkap!";
    header("Location: forgot.php");
}
