<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);

if(!isset($_SESSION['step_reset_petugas'])){
    $_SESSION['msg'] = "Silakan lakukan verifikasi OTP terlebih dahulu.";
    header("Location: forgot_petugas.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password Petugas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Buat password baru untuk akun petugas.</small>
    </div>
  </div>
  <h1 class="page-title">Reset Password Petugas</h1>
  <p class="page-subtitle">Masukkan password baru dan lanjutkan login petugas.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_reset_petugas.php">
    <div class="form-group">
      <input class="input" type="password" name="password" placeholder="Password Baru" required>
    </div>
    <div class="form-actions">
      <button class="button button-primary" type="submit">Reset Password</button>
    </div>
    <div class="form-footer">
      <a href="login_petugas.php">Kembali ke Login Petugas</a>
    </div>
  </form>
</div>
</body>
</html>
