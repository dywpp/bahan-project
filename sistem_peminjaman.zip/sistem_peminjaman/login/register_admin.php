<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Register Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Daftar admin untuk kelola sistem.</small>
    </div>
  </div>
  <h1 class="page-title">Register Admin</h1>
  <p class="page-subtitle">Buat akun admin untuk mengelola data peminjaman dan pengguna.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_register_admin.php">
    <div class="form-group">
      <input class="input" type="text" name="nama" placeholder="Nama Lengkap" required>
    </div>
    <div class="form-group">
      <input class="input" type="email" name="email" placeholder="Email" required>
    </div>
    <div class="form-group">
      <input class="input" type="password" name="password" placeholder="Password" required>
    </div>
    <div class="form-actions">
      <button class="button button-primary" type="submit">Register</button>
    </div>
    <div class="form-footer">
      <a href="login_admin.php">Sudah punya akun? Login Admin</a>
    </div>
  </form>
