<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Register Petugas</title>
<style>
/* Sama desain login */
body{
 margin:0;
 min-height:100vh;
 background: #f0e6d2;
 font-family: 'Montserrat', sans-serif;
 display:flex;
 justify-content:center;
 align-items:center;
 color:#333;
}
.container{
 width:400px;
 padding:40px;
 background:#fff;
 border-radius:15px;
 box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}
h1{
 margin:0 0 20px 0;
 text-align:center;
 font-weight:600;
 color:#4a3f35;
}
form{
 display:flex;
 flex-direction:column;
 gap:15px;
}
input{
 padding:12px;
 border-radius:8px;
 border:1px solid #ccc;
 outline:none;
 font-size:14px;
 background:#fdf6e3;
 color:#333;
 transition:0.2s;
}
input:focus{
 border-color:#a67c52;
 box-shadow:0 0 5px rgba(166,124,82,0.5);
}
button{
 padding:12px;
 border-radius:8px;
 border:none;
 font-weight:600;
 font-size:15px;
 cursor:pointer;
 background:#a67c52;
 color:#fff;
 transition:0.3s;
}
button:hover{
 background:#8b5e3c;
 box-shadow:0 4px 10px rgba(0,0,0,0.15);
}
.msg{
 text-align:center;
 font-size:14px;
 color:#c0392b;
 margin-bottom:10px;
}
.link{
 font-size:13px;
 color:#4a3f35;
 cursor:pointer;
 text-align:center;
 text-decoration:underline;
}
</style>
</head>
<body>
<div class="container">
<h1>Register Petugas</h1>
<?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
<form method="post" action="proses_register_petugas.php">
<input type="text" name="nama" placeholder="Nama Lengkap" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>
<button>Register</button>
<div class="link"><a href="login_petugas.php">Kembali ke Login</a></div>
</form>
</div>
</body>
</html>
