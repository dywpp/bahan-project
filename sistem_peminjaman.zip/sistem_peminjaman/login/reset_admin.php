<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);

if(!isset($_SESSION['otp_email_admin'])){
    $_SESSION['msg'] = "Akses tidak valid. Silakan mulai dari lupa password.";
    header("Location: forgot_admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Reset password admin dengan mudah.</small>
    </div>
  </div>
  <h1 class="page-title">Reset Password Admin</h1>
  <p class="page-subtitle">Masukkan OTP dan password baru untuk kembali mengakses akun admin.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_reset_admin.php">
    <div class="form-group">
      <input class="input" type="text" name="otp" placeholder="Masukkan OTP" required>
    </div>
    <div class="form-group">
      <input class="input" type="password" name="password" placeholder="Password Baru" required>
    </div>
    <div class="form-actions">
      <button class="button button-primary" type="submit">Reset Password</button>
    </div>
    <div class="form-footer">
      <a href="login_admin.php">Kembali Login Admin</a>
    </div>
  </form>
</div>
</body>
</html>
