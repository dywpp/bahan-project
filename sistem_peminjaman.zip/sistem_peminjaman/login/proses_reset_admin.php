<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['otp'],$_POST['password'])){
    if(!isset($_SESSION['otp']) || !isset($_SESSION['otp_email'])){
        $_SESSION['msg'] = "Sesi OTP hilang!";
        header("Location: forgot_admin.php");
        exit;
    }

    $otp = $_POST['otp'];
    $password = password_hash($_POST['password'],PASSWORD_DEFAULT);
    $email = $_SESSION['otp_email'];

    if($otp != $_SESSION['otp'] || (time() - $_SESSION['otp_time']) > 300){
        $_SESSION['msg'] = "OTP salah atau kadaluarsa!";
        header("Location: reset_admin.php");
        exit;
    }

    $stmt = $koneksi->prepare("UPDATE users SET password=? WHERE email=? AND role='admin'");
    $stmt->bind_param("ss",$password,$email);

    if($stmt->execute()){
        session_destroy();
        $_SESSION['msg'] = "Password berhasil direset, silakan login!";
        header("Location: login_admin.php");
    }else{
        $_SESSION['msg'] = "Terjadi kesalahan: ".$stmt->error;
        header("Location: reset_admin.php");
    }
}
?>
