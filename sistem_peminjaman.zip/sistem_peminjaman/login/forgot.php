<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);
$otp_sent = isset($_SESSION['otp_email']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Lupa Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Memulihkan akses akun Anda dengan OTP.</small>
    </div>
  </div>
  <h1 class="page-title">Lupa Password</h1>
  <p class="page-subtitle">Masukkan email untuk menerima kode OTP atau reset password Anda.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_forgot.php">
    <?php if(!$otp_sent): ?>
      <div class="form-group">
        <input class="input" type="email" name="email" placeholder="Masukkan Email" required>
      </div>
      <div class="form-actions">
        <button class="button button-primary" type="submit">Kirim Kode OTP</button>
      </div>
    <?php else: ?>
      <div class="form-group">
        <input class="input" type="email" name="email" value="<?php echo htmlspecialchars($_SESSION['otp_email']); ?>" readonly>
      </div>
      <div class="form-group">
        <input class="input" type="text" name="otp" placeholder="Masukkan OTP" required>
      </div>
      <div class="form-group">
        <input class="input" type="password" name="password" placeholder="Password Baru" required>
      </div>
      <div class="form-actions">
        <button class="button button-primary" type="submit">Reset Password</button>
      </div>
    <?php endif; ?>
    <div class="form-footer">
      <a href="login.php">Kembali ke Login</a>
    </div>
  </form>
</div>
</body>
</html>
