<?php
session_start();
include "../config/koneksi.php";

if(!isset($_SESSION['step_reset_petugas'])){
    $_SESSION['msg'] = "Silakan lakukan verifikasi OTP terlebih dahulu.";
    header("Location: forgot_petugas.php");
    exit;
}

if(isset($_POST['password'])){
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_SESSION['otp_email_petugas'];

    $stmt = $koneksi->prepare("UPDATE users SET password=? WHERE email=? AND role='petugas'");
    $stmt->bind_param("ss",$password,$email);

    if($stmt->execute()){
        unset($_SESSION['step_reset_petugas']);
        unset($_SESSION['otp_petugas']);
        unset($_SESSION['otp_email_petugas']);
        unset($_SESSION['otp_time_petugas']);

        $_SESSION['msg'] = "Password berhasil direset, silakan login.";
        header("Location: login_petugas.php");
        exit;
    } else {
        $_SESSION['msg'] = "Gagal reset password!";
        header("Location: reset_petugas.php");
        exit;
    }
}
