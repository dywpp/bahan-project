<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['nama'], $_POST['email'], $_POST['password'])){
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Cek apakah email sudah ada di tabel users
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0){
        $_SESSION['msg'] = "Email sudah terdaftar!";
        header("Location: register_admin.php");
        exit;
    }
    $stmt->close();

    // Insert admin baru
    $stmt = $koneksi->prepare("INSERT INTO users(nama,email,password,role,status) VALUES(?,?,?,'admin','aktif')");
    $stmt->bind_param("sss",$nama,$email,$password);

    if($stmt->execute()){
        $_SESSION['msg'] = "Register berhasil, silakan login!";
        header("Location: login_admin.php");
    }else{
        $_SESSION['msg'] = "Terjadi kesalahan: ".$stmt->error;
        header("Location: register_admin.php");
    }
}
?>
