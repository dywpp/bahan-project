<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Admin login area</small>
    </div>
  </div>
  <h1 class="page-title">Login Admin</h1>
  <p class="page-subtitle">Masuk dengan akun admin untuk mengelola sistem.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_login_admin.php">
    <div class="form-group">
      <input class="input" type="email" name="email" placeholder="Email" required>
    </div>
    <div class="form-group">
      <input class="input" type="password" name="password" placeholder="Password" required>
    </div>
    <div class="form-actions">
      <button class="button button-primary" type="submit">Login</button>
    </div>
    <div class="form-footer">
      <a href="register_admin.php">Belum punya akun? Register</a> · <a href="forgot_admin.php">Lupa Password?</a>
    </div>
  </form>
</div>
</body>
</html>
