<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['email'], $_POST['password'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $koneksi->prepare("SELECT id_user,nama,password,role FROM users WHERE email=? AND role='petugas'");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($user = $result->fetch_assoc()){
        if(password_verify($password, $user['password'])){
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['role'] = $user['role'];

            header("Location: ../dashboard/petugas.php");
            exit;
        } else {
            $_SESSION['msg'] = "Password salah!";
            header("Location: login_petugas.php");
            exit;
        }
    } else {
        $_SESSION['msg'] = "Email tidak terdaftar atau bukan petugas!";
        header("Location: login_petugas.php");
        exit;
    }
}
?>
