<?php
session_start();
$msg = isset($_SESSION['msg']) ? $_SESSION['msg'] : '';
unset($_SESSION['msg']);

if(!isset($_SESSION['otp_petugas'])){
    $_SESSION['msg'] = "Silakan lakukan request OTP terlebih dahulu.";
    header("Location: forgot_petugas.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Verifikasi OTP Petugas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">

</head>
<body class="auth-layout">
<div class="auth-card">
  <div class="brand">
    <div class="logo">SP</div>
    <div class="brand-text">
      <span>Sistem Peminjaman</span>
      <small>Verifikasi OTP petugas untuk melanjutkan reset.</small>
    </div>
  </div>
  <h1 class="page-title">Verifikasi OTP Petugas</h1>
  <p class="page-subtitle">Masukkan kode OTP yang dikirim ke email Anda.</p>
  <?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
  <form method="post" action="proses_verify_petugas.php">
    <div class="form-group">
      <input class="input" type="text" name="otp" placeholder="Masukkan OTP" required>
    </div>
    <div class="form-actions">
      <button class="button button-primary" type="submit">Verifikasi</button>
    </div>
    <div class="form-footer">
      <a href="forgot_petugas.php">Kirim ulang OTP</a>
    </div>
  </form>
</div>
</body>
</html>
