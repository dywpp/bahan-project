<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['nama'], $_POST['email'], $_POST['password'])){
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // cek email apakah sudah terdaftar
    $stmt = $koneksi->prepare("SELECT id_user FROM users WHERE email=? AND role='petugas'");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0){
        $_SESSION['msg'] = "Email sudah terdaftar!";
        header("Location: register_petugas.php");
        exit;
    }

    // insert data baru
    $stmt = $koneksi->prepare("INSERT INTO users (nama,email,password,role,status) VALUES (?,?,?,'petugas','aktif')");
    $stmt->bind_param("sss",$nama,$email,$password);

    if($stmt->execute()){
        $_SESSION['msg'] = "Registrasi berhasil, silakan login.";
        header("Location: login_petugas.php");
        exit;
    } else {
        $_SESSION['msg'] = "Terjadi kesalahan: " . $stmt->error;
        header("Location: register_petugas.php");
        exit;
    }
}
