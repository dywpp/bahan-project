<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['email'],$_POST['password'])){
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $stmt = $koneksi->prepare("SELECT id_user,nama,password FROM users WHERE email=? AND role='admin'");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user && password_verify($pass,$user['password'])){
        $_SESSION['id_user'] = $user['id_user'];
        $_SESSION['nama'] = $user['nama'];
        $_SESSION['role'] = 'admin';
        header("Location: ../dashboard/admin.php");
        exit;
    }else{
        $_SESSION['msg'] = "Login gagal, email atau password salah!";
        header("Location: login_admin.php");
        exit;
    }
}
?>
