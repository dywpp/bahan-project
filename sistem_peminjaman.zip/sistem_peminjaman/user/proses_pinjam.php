<?php
session_start();
include "../config/koneksi.php";

$id_user = $_SESSION['id_user'];

// CEK STATUS USER
$q = mysqli_query($koneksi, "
    SELECT status, blacklist 
    FROM users 
    WHERE id_user='$id_user'
");
$u = mysqli_fetch_assoc($q);

if ($u['blacklist'] == 'ya') {
    die("Akun diblacklist permanen");
}

if ($u['status'] == 'suspend') {
    die("Akun disuspend, lunasi denda dulu");
}

// LANJUT INSERT (DB TRIGGER JUGA CEK)
mysqli_query($koneksi, "
    INSERT INTO peminjaman (id_user, tgl_pinjam, status)
    VALUES ('$id_user', CURDATE(), 'pending')
");

echo "Peminjaman berhasil diajukan";
