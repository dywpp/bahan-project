<?php
session_start();
include "../config/koneksi.php";

$id_user = $_SESSION['id_user'];

$q = mysqli_query($koneksi,"
  SELECT * FROM peminjaman
  WHERE id_user='$id_user' AND status='approved'
");
?>

<table border="1">
<tr>
  <th>Tanggal Pinjam</th>
  <th>Aksi</th>
</tr>

<?php while($p=mysqli_fetch_assoc($q)){ ?>
<tr>
  <td><?= $p['tgl_pinjam'] ?></td>
  <td>
    <a href="proses_kembali.php?id=<?= $p['id_peminjaman'] ?>">
      Kembalikan
    </a>
  </td>
</tr>
<?php } ?>
</table>
