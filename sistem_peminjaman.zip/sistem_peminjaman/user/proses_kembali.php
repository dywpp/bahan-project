<?php
include "../config/koneksi.php";

$id = $_POST['id'];

$namaFile = time().'_'.$_FILES['bukti']['name'];
move_uploaded_file(
  $_FILES['bukti']['tmp_name'],
  "../uploads/".$namaFile
);

mysqli_query($koneksi,"
  UPDATE peminjaman
  SET status='returned',
      tgl_kembali=CURDATE(),
      bukti='$namaFile'
  WHERE id_peminjaman='$id'
");

header("Location: pengembalian.php");
