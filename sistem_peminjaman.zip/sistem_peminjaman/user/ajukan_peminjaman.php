<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login/cek_petugas.php");
    exit;
}

include __DIR__ . '/../config/koneksi.php';

$id_user = $_SESSION['id_user'];

// ambil barang tersedia
$qBarang = mysqli_query($koneksi, "SELECT * FROM barang");
if (!$qBarang) die("Query error: " . mysqli_error($koneksi));
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard User - Peminjaman</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{
  --bg:#f5f2ec;
  --panel:#fff;
  --accent:#5f8cff;
  --text:#333;
  --muted:#666;
}
*{box-sizing:border-box;margin:0;padding:0;font-family:'Montserrat',sans-serif;}
body{background:var(--bg);}
.wrapper{display:flex;min-height:100vh;}

/* Sidebar */
.sidebar{
  width:220px;
  background:#141821;
  color:#e6e9ef;
  display:flex;
  flex-direction:column;
  padding:20px;
}
.sidebar h2{margin-bottom:30px;color:var(--accent);}
.sidebar a{
  text-decoration:none;
  color:#e6e9ef;
  padding:12px 15px;
  border-radius:8px;
  margin-bottom:8px;
  display:block;
  transition:0.3s;
}
.sidebar a:hover{background:var(--accent);color:#fff;}

/* Main content */
.main{
  flex:1;
  padding:30px;
}
.panel{
  background:var(--panel);
  padding:25px;
  border-radius:15px;
  box-shadow:0 6px 15px rgba(0,0,0,0.1);
  max-width:600px;
  margin:auto;
}
.panel h2{
  text-align:center;
  margin-bottom:20px;
  color:var(--accent);
}
.form-group{margin-bottom:15px;}
.form-group label{display:block;margin-bottom:5px;color:var(--text);font-weight:600;}
.form-group input, .form-group select{
  width:100%;
  padding:10px;
  border-radius:8px;
  border:1px solid #ccc;
  font-size:14px;
}
button{
  width:100%;
  padding:12px;
  background:var(--accent);
  color:#fff;
  border:none;
  border-radius:8px;
  font-size:16px;
  font-weight:600;
  cursor:pointer;
  transition:0.3s;
}
button:hover{background:#4f7ce0;}

/* Responsive */
@media(max-width:768px){
  .wrapper{flex-direction:column;}
  .sidebar{width:100%;flex-direction:row;flex-wrap:wrap;}
  .sidebar a{flex:1;text-align:center;}
}
</style>
</head>
<body>

<div class="wrapper">

  <!-- Sidebar -->
  <div class="sidebar">
    <h2>Dashboard</h2>
    <a href="user_dashboard.php">Beranda</a>
    <a href="pinjam_barang.php">Pinjam Barang</a>
    <a href="riwayat.php">Riwayat</a>
    <a href="../login/logout.php">Logout</a>
  </div>

  <!-- Main Content -->
  <div class="main">
    <div class="panel">
      <h2>Ajukan Peminjaman Barang</h2>
      <form action="proses_pinjam.php" method="post">
        
        <div class="form-group">
          <label>Barang</label>
          <select name="id_barang" required>
            <option value="">-- Pilih Barang --</option>
            <?php while($barang = mysqli_fetch_assoc($qBarang)): ?>
            <option value="<?= $barang['id_barang'] ?>">
              <?= htmlspecialchars($barang['nama_barang']) ?>
            </option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="form-group">
          <label>Jumlah</label>
          <input type="number" name="jumlah" min="1" required>
        </div>

        <div class="form-group">
          <label>Tanggal Pinjam</label>
          <input type="date" name="tanggal_pinjam" required>
        </div>

        <button type="submit">Ajukan Peminjaman</button>
      </form>
    </div>
  </div>

</div>

</body>
</html>
