<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login/login.php");
    exit;
}

include __DIR__ . '/../config/koneksi.php';

$id_user = $_SESSION['id_user'];

// ambil barang tersedia
$qBarang = mysqli_query($koneksi, "SELECT * FROM barang");
if (!$qBarang) die("Query error: " . mysqli_error($koneksi));
?>

<!DOCTYPE html>
<html>
<head>
<title>Ajukan Peminjaman</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="wrapper">
  <div class="sidebar">
    <h2>Dashboard User</h2>
    <a href="../dashboard/user.php">Beranda</a>
    <a href="../data/search_barang.php">Daftar Alat</a>
    <a href="pengembalian.php">Pengembalian</a>
    <a href="../login/logout.php">Logout</a>
  </div>

  <div class="main">
    <div class="panel">
      <h2>Ajukan Peminjaman</h2>
      <form action="proses_pinjam.php" method="post">
        <div class="form-group">
          <label for="id_barang">Barang</label>
          <select id="id_barang" name="id_barang" required>
            <option value="">-- Pilih Barang --</option>
            <?php while($barang = mysqli_fetch_assoc($qBarang)): ?>
            <option value="<?= $barang['id_barang'] ?>"><?= htmlspecialchars($barang['nama_barang']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="jumlah">Jumlah</label>
          <input id="jumlah" type="number" name="jumlah" min="1" required>
        </div>

        <div class="form-group">
          <label for="tanggal_pinjam">Tanggal Pinjam</label>
          <input id="tanggal_pinjam" type="date" name="tanggal_pinjam" required>
        </div>

        <button type="submit">Ajukan Peminjaman</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
