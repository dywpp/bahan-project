<?php
session_start();
include "../config/koneksi.php";

// Cek login
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/auth.php");
    exit;
}

// Ambil data user
$id_user = $_SESSION['id_user'];
$nama = $_SESSION['nama'];

// Ambil riwayat aktivitas
$riwayat = mysqli_query($koneksi,"SELECT * FROM activity_log WHERE id_user='$id_user' ORDER BY created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard User</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="site-layout">
    <div class="main-content">
        <div class="page-header">
            <h1>Selamat Datang, <?=htmlspecialchars($nama)?></h1>
            <div class="page-actions">
                <form method="post" action="../login/logout.php">
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
            </div>
        </div>

        <div class="card-grid">

            <!-- Card statistik singkat -->
            <div class="card">
                <div class="card-header">
                    <h3>Profil</h3>
                </div>
                <div class="card-body">
                    <p><strong>Nama:</strong> <?=htmlspecialchars($nama)?></p>
                    <p><strong>Role:</strong> User</p>
                    <p><strong>ID User:</strong> <?=$id_user?></p>
                </div>
            </div>

            <!-- Card riwayat aktivitas -->
            <div class="card">
                <div class="card-header">
                    <h3>Riwayat Aktivitas Terakhir</h3>
                </div>
                <div class="card-body">
                    <?php if(mysqli_num_rows($riwayat)>0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Aktivitas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($r = mysqli_fetch_assoc($riwayat)): ?>
                            <tr>
                                <td><?=date('d M Y H:i', strtotime($r['created_at']))?></td>
                                <td><?=htmlspecialchars($r['activity'])?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <p class="text-muted">Belum ada aktivitas.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
