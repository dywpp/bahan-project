<?php
session_start();
include "../config/koneksi.php";

// Cek login
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/auth.php");
    exit;
}

// Ambil data user
$id_user = $_SESSION['id_user'];
$nama = $_SESSION['nama'];

// Ambil riwayat aktivitas
$riwayat = mysqli_query($koneksi,"SELECT * FROM activity_log WHERE id_user='$id_user' ORDER BY created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard User</title>
<style>
/* Reset & font */
body, html{margin:0;padding:0;font-family: 'Segoe UI', sans-serif;background:#f0f4f8;color:#333;}
a{text-decoration:none;color:inherit;}

/* Layout */
header{background:#4a90e2;color:#fff;padding:20px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 4px 6px rgba(0,0,0,0.1);}
header h1{margin:0;font-size:24px;}
nav button{padding:10px 20px;background:#ff5e5e;border:none;border-radius:8px;color:#fff;font-weight:600;cursor:pointer;transition:0.3s;}
nav button:hover{opacity:.85;}

/* Main container */
.container{display:flex;gap:20px;padding:20px;flex-wrap:wrap;}
.card{background:#fff;border-radius:16px;padding:20px;flex:1;min-width:300px;box-shadow:0 6px 18px rgba(0,0,0,0.08);transition:0.3s;}
.card:hover{transform:translateY(-5px);box-shadow:0 10px 25px rgba(0,0,0,0.15);}

/* Riwayat table */
table{width:100%;border-collapse:collapse;margin-top:10px;}
th,td{padding:12px;text-align:left;border-bottom:1px solid #eee;}
th{background:#f5f9ff;color:#4a90e2;}
tr:hover{background:#f1f6ff;}

/* Animasi */
.fade-in{animation:fadeIn 0.8s ease;}
@keyframes fadeIn{
  0%{opacity:0; transform:translateY(20px);}
  100%{opacity:1; transform:translateY(0);}
}
</style>
</head>
<body>

<header>
    <h1>Selamat Datang, <?=htmlspecialchars($nama)?></h1>
    <nav>
        <form method="post" action="../auth/logout.php">
            <button type="submit">Logout</button>
        </form>
    </nav>
</header>

<div class="container fade-in">

    <!-- Card statistik singkat -->
    <div class="card">
        <h2>Profil</h2>
        <p><strong>Nama:</strong> <?=htmlspecialchars($nama)?></p>
        <p><strong>Role:</strong> User</p>
        <p><strong>ID User:</strong> <?=$id_user?></p>
    </div>

    <!-- Card riwayat aktivitas -->
    <div class="card">
        <h2>Riwayat Aktivitas Terakhir</h2>
        <?php if(mysqli_num_rows($riwayat)>0): ?>
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Aktivitas</th>
                </tr>
            </thead>
            <tbody>
                <?php while($r = mysqli_fetch_assoc($riwayat)): ?>
                <tr>
                    <td><?=date('d M Y H:i', strtotime($r['created_at']))?></td>
                    <td><?=htmlspecialchars($r['activity'])?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>Belum ada aktivitas</p>
        <?php endif; ?>
    </div>

</div>

</body>
</html>
