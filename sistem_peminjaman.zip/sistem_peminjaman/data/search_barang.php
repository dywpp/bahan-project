<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login/login.php");
    exit;
}

include __DIR__ . '/../config/koneksi.php';

/* =========================
   MODE AJAX
========================= */
if (isset($_GET['ajax'])) {
    $q = $_GET['q'] ?? '';
    $where = "";

    if ($q != '') {
        $safe = mysqli_real_escape_string($koneksi, $q);
        $where = "WHERE nama_barang LIKE '%$safe%'";
    }

    $sql = "SELECT * FROM barang $where ORDER BY nama_barang ASC";
    $query = mysqli_query($koneksi, $sql);

    if (mysqli_num_rows($query) == 0) {
        echo "<div class='empty'>🔍 Barang tidak ditemukan</div>";
        exit;
    }

    while ($b = mysqli_fetch_assoc($query)) {
        $stok = (int)$b['stok'];
        ?>
        <div class="card">
            <h4><?= htmlspecialchars($b['nama_barang']); ?></h4>

            <div class="stok">
                Stok: <?= $stok ?><br>
                <span class="badge <?= $stok > 0 ? 'ok' : 'habis' ?>">
                    <?= $stok > 0 ? 'Tersedia' : 'Habis' ?>
                </span>
            </div>

            <?php if ($stok > 0) { ?>
            <div class="action">
                <button onclick="alert('Pinjam: <?= htmlspecialchars($b['nama_barang']); ?>')">
                    ⚡ Pinjam Cepat
                </button>
            </div>
            <?php } ?>
        </div>
        <?php
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Barang Explorer</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="wrapper">
    <div class="header">
        <h2>📦 Barang Explorer</h2>
        <input type="text" id="keyword" class="search" placeholder="Cari barang...">
    </div>

    <div class="grid" id="result"></div>
</div>

<script>
let timer;

function loadBarang(){
    const q = document.getElementById('keyword').value;

    fetch(`?ajax=1&q=${encodeURIComponent(q)}`)
        .then(res => res.text())
        .then(html => {
            document.getElementById('result').innerHTML = html;
        });
}

document.getElementById('keyword').addEventListener('keyup',()=>{
    clearTimeout(timer);
    timer = setTimeout(loadBarang,300);
});

loadBarang();
</script>

</body>
</html>
