<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login/login.php");
    exit;
}

include __DIR__ . '/../config/koneksi.php';

/* =========================
   MODE AJAX
========================= */
if (isset($_GET['ajax'])) {
    $q = $_GET['q'] ?? '';
    $where = "";

    if ($q != '') {
        $safe = mysqli_real_escape_string($koneksi, $q);
        $where = "WHERE nama_barang LIKE '%$safe%'";
    }

    $sql = "SELECT * FROM barang $where ORDER BY nama_barang ASC";
    $query = mysqli_query($koneksi, $sql);

    if (mysqli_num_rows($query) == 0) {
        echo "<div class='empty'>🔍 Barang tidak ditemukan</div>";
        exit;
    }

    while ($b = mysqli_fetch_assoc($query)) {
        $stok = (int)$b['stok'];
        ?>
        <div class="card">
            <h4><?= htmlspecialchars($b['nama_barang']); ?></h4>

            <div class="stok">
                Stok: <?= $stok ?><br>
                <span class="badge <?= $stok > 0 ? 'ok' : 'habis' ?>">
                    <?= $stok > 0 ? 'Tersedia' : 'Habis' ?>
                </span>
            </div>

            <?php if ($stok > 0) { ?>
            <div class="action">
                <button onclick="alert('Pinjam: <?= htmlspecialchars($b['nama_barang']); ?>')">
                    ⚡ Pinjam Cepat
                </button>
            </div>
            <?php } ?>
        </div>
        <?php
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Barang Explorer</title>

<style>
*{box-sizing:border-box}
body{
    font-family:Inter,Arial;
    background:#f5f7ff;
    padding:30px;
}

.wrapper{
    max-width:1100px;
    margin:auto;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.search{
    width:320px;
    padding:12px 16px;
    border-radius:12px;
    border:1px solid #ddd;
    font-size:15px;
}

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
    gap:16px;
}

.card{
    background:#fff;
    border-radius:16px;
    padding:16px;
    box-shadow:0 8px 25px rgba(0,0,0,.06);
    transition:.35s;
    position:relative;
    overflow:hidden;
}

.card:hover{
    transform:translateY(-6px);
    box-shadow:0 15px 40px rgba(0,0,0,.12);
}

.card h4{
    margin:0 0 6px;
    font-size:16px;
}

.stok{font-size:14px}

.badge{
    display:inline-block;
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.ok{background:#dcfce7;color:#166534}
.habis{background:#fee2e2;color:#991b1b}

.action{
    position:absolute;
    inset:auto 0 0 0;
    padding:12px;
    background:linear-gradient(transparent,#fff 60%);
    transform:translateY(100%);
    transition:.3s;
}

.card:hover .action{
    transform:translateY(0);
}

.action button{
    width:100%;
    padding:10px;
    border:none;
    border-radius:10px;
    background:#4f46e5;
    color:#fff;
    cursor:pointer;
}

.empty{
    grid-column:1/-1;
    text-align:center;
    padding:60px;
    color:#888;
}
</style>
</head>
<body>

<div class="wrapper">
    <div class="header">
        <h2>📦 Barang Explorer</h2>
        <input type="text" id="keyword" class="search" placeholder="Cari barang...">
    </div>

    <div class="grid" id="result"></div>
</div>

<script>
let timer;

function loadBarang(){
    const q = document.getElementById('keyword').value;

    fetch(`?ajax=1&q=${encodeURIComponent(q)}`)
        .then(res => res.text())
        .then(html => {
            document.getElementById('result').innerHTML = html;
        });
}

document.getElementById('keyword').addEventListener('keyup',()=>{
    clearTimeout(timer);
    timer = setTimeout(loadBarang,300);
});

loadBarang();
</script>

</body>
</html>
