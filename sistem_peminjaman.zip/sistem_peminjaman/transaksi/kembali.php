<?php
include __DIR__ . '/../config/koneksi.php';

$q = mysqli_query($koneksi, "
    SELECT 
        p.id_peminjaman,
        b.nama_barang,
        d.jumlah
    FROM peminjaman p
    JOIN detail_peminjaman d ON p.id_peminjaman = d.id_peminjaman
    JOIN barang b ON d.id_barang = b.id_barang
    WHERE p.status = 'dipinjam'
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pengembalian Barang</title>
<link rel="stylesheet" href="../assets/style.css">
<style>
body{
    margin:0;
    font-family: 'Segoe UI', sans-serif;
    background:#0e1014;
    color:#eaeaea;
}
.container{
    max-width:900px;
    margin:40px auto;
    background:#141820;
    padding:25px;
    border-radius:12px;
    box-shadow:0 0 20px rgba(0,0,0,0.5);
}
h2{margin:0;}
.subtitle{color:#9aa0aa;margin-bottom:20px;}
table{width:100%;border-collapse:collapse;}
th{
    background:#1c2230;
    padding:12px;
    text-align:left;
}
td{
    padding:12px;
    border-bottom:1px solid #232a3a;
}
tr:hover{background:#1a2030;}
.btn{
    padding:8px 14px;
    background:#2f6bff;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
    font-size:13px;
    transition:0.2s;
}
.btn:hover{background:#1f52cc;}
</style>
</head>

<body>

<div class="container">
    <h2>Pengembalian Barang</h2>
    <p class="subtitle">Daftar barang yang sedang dipinjam</p>

    <table>
        <tr>
            <th>ID</th>
            <th>Barang</th>
            <th>Jumlah</th>
            <th>Aksi</th>
        </tr>

        <?php while($r = mysqli_fetch_assoc($q)) { ?>
        <tr>
            <td><?= $r['id_peminjaman'] ?></td>
            <td><?= $r['nama_barang'] ?></td>
            <td><?= $r['jumlah'] ?></td>
            <td>
                <a class="btn" href="proses_kembali.php?id=<?= $r['id_peminjaman'] ?>">
                    Kembalikan
                </a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>
