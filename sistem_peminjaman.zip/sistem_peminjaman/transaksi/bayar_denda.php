<?php
session_start();
include "../config/koneksi.php";

$id_peminjaman = $_POST['id_peminjaman'];
$id_user = $_SESSION['id_user'];
$jumlah = $_POST['jumlah'];

mysqli_query($koneksi, "
    INSERT INTO pembayaran_denda 
    (id_peminjaman, id_user, jumlah, tgl_bayar, metode)
    VALUES 
    ('$id_peminjaman','$id_user','$jumlah',CURDATE(),'cash')
");

echo "Denda dibayar, akun aktif kembali";
