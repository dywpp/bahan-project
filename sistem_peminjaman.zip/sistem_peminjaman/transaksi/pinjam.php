<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login/login.php");
    exit;
}

include __DIR__ . '/../config/koneksi.php';

$id_user = $_SESSION['id_user'];

// ambil barang tersedia
$qBarang = mysqli_query($koneksi, "SELECT * FROM barang");
if(!$qBarang){
    die("Query error: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<title>Pinjam Barang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="site-layout">
  <div class="sidebar">
    <h2>Dashboard User</h2>
    <nav class="sidebar-nav">
      <a href="../dashboard/user.php">Home</a>
      <a href="../user/ajukan_peminjaman.php">Peminjaman</a>
      <a href="../data/search_barang.php">Daftar Alat</a>
      <a href="../login/logout.php">Logout</a>
    </nav>
  </div>

  <div class="main-content">
    <div class="panel">
      <div class="panel-header">
        <h2>Pinjam Barang</h2>
      </div>
      <div class="panel-body">
        <form action="../user/proses_pinjam.php" method="POST">
          <div class="form-group">
            <label for="id_barang">Barang</label>
            <select id="id_barang" name="id_barang" required>
              <option value="">-- Pilih Barang --</option>
              <?php while($barang = mysqli_fetch_assoc($qBarang)): ?>
              <option value="<?= $barang['id_barang'] ?>"><?= htmlspecialchars($barang['nama_barang']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input id="jumlah" type="number" name="jumlah" min="1" required>
          </div>

          <div class="form-group">
            <label for="tanggal_pinjam">Tanggal Pinjam</label>
            <input id="tanggal_pinjam" type="date" name="tanggal_pinjam" required>
          </div>

          <button type="submit" class="btn btn-primary">Pinjam Barang</button>
        </form>
      </div>
    </div>
  </div>
</div>

</body>
</html>
