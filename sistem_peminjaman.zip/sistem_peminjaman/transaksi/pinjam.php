<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login/cek_petugas.php");
    exit;
}

include __DIR__ . '/../config/koneksi.php';

$id_user = $_SESSION['id_user'];

// ambil barang tersedia
$qBarang = mysqli_query($koneksi, "SELECT * FROM barang");

if(!$qBarang){
    die("Query error: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Pinjam Barang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{
 --bg:#0e1014; --panel:#141821; --card:#171c26; --border:#1f2533;
 --text:#e6e9ef; --muted:#9aa4b2; --accent:#5f8cff;
}
body{
    margin:0;
    font-family:'Montserrat',sans-serif;
    background:var(--bg);
    color:var(--text);
}
.container{
    display:flex;
    max-width:1200px;
    margin:auto;
    min-height:100vh;
}
/* Sidebar */
.sidebar{
    width:220px;
    background:#1f2533;
    padding:20px;
}
.sidebar h2{
    margin-top:0;
    font-size:20px;
    color:var(--accent);
}
.sidebar a{
    display:block;
    color:var(--text);
    text-decoration:none;
    padding:10px;
    margin:8px 0;
    border-radius:6px;
    transition:0.3s;
}
.sidebar a:hover{
    background:var(--accent);
    color:#fff;
}

/* Main */
.main{
    flex:1;
    padding:20px;
}

/* Panel Form */
.panel{
    background:var(--panel);
    padding:20px;
    border-radius:14px;
    box-shadow:0 4px 12px rgba(0,0,0,0.2);
    max-width:600px;
    margin:auto;
}
.panel h3{
    margin-top:0;
    color:var(--accent);
}

/* Form */
form{
    display:flex;
    flex-direction:column;
}
form label{
    margin-top:10px;
    margin-bottom:5px;
    font-weight:500;
    color:var(--text);
}
form input, form select{
    padding:10px;
    border-radius:8px;
    border:1px solid var(--border);
    background:var(--card);
    color:var(--text);
}
form button{
    margin-top:15px;
    padding:10px;
    background:var(--accent);
    border:none;
    color:#fff;
    border-radius:8px;
    cursor:pointer;
    font-weight:600;
    transition:0.3s;
}
form button:hover{
    opacity:0.85;
}

/* Responsive */
@media(max-width:768px){
    .container{
        flex-direction:column;
    }
    .panel{
        width:100%;
        margin:auto;
    }
}
</style>
</head>
<body>

<div class="container">
    <div class="sidebar">
        <h2>Dashboard User</h2>
        <a href="user_dashboard.php">Home</a>
        <a href="../user/ajukan_peminjaman.php">Peminjaman</a>
        <a href="../transaksi/pinjam.php">Pinjam Barang</a>
        <a href="../login/logout.php">Logout</a>
    </div>

    <div class="main">
        <div class="panel">
            <h3>Form Peminjaman Barang</h3>
            <form action="proses_pinjam.php" method="POST">
                <label>Barang</label>
                <select name="id_barang" required>
                    <option value="">-- Pilih Barang --</option>
                    <?php while($barang = mysqli_fetch_assoc($qBarang)): ?>
                        <option value="<?= $barang['id_barang'] ?>">
                            <?= htmlspecialchars($barang['nama_barang']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label>Jumlah</label>
                <input type="number" name="jumlah" min="1" required>

                <label>Tanggal Pinjam</label>
                <input type="date" name="tanggal_pinjam" required>

                <button type="submit">Pinjam Barang</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
