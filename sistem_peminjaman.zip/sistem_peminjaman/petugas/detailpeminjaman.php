<?php
include "../config/koneksi.php";
$id = $_GET['id'];

$q = mysqli_query($koneksi,"
  SELECT b.nama_barang, d.jumlah
  FROM peminjaman_detail d
  JOIN barang b ON d.id_barang=b.id_barang
  WHERE d.id_peminjaman='$id'
");
?>

<h3>Detail Barang</h3>
<ul>
<?php while($r=mysqli_fetch_assoc($q)){ ?>
  <li><?= $r['nama_barang'] ?> x <?= $r['jumlah'] ?></li>
<?php } ?>
</ul>
