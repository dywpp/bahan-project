<?php
include "../config/koneksi.php";

$q = mysqli_query($koneksi,"
  SELECT p.*, u.nama
  FROM peminjaman p
  JOIN users u ON p.id_user=u.id_user
  WHERE p.status='returned'
");
?>

<table border="1">
<tr>
  <th>User</th><th>Bukti</th><th>Denda</th>
</tr>

<?php while($r=mysqli_fetch_assoc($q)){ ?>
<tr>
  <td><?= $r['nama'] ?></td>
  <td>
    <a href="../uploads/<?= $r['bukti'] ?>" target="_blank">
      Lihat
    </a>
  </td>
  <td><?= $r['denda'] ?></td>
</tr>
<?php } ?>
</table>
