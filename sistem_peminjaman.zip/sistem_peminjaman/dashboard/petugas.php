<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role']!='petugas'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

// Hitung total data
$total_pending = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman WHERE status='pending'")) ? $result->fetch_assoc()['total'] : 0;
$total_approved = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman WHERE status='approved'")) ? $result->fetch_assoc()['total'] : 0;
$total_pengembalian = ($result=$koneksi->query("SELECT COUNT(*) as total FROM pengembalian")) ? $result->fetch_assoc()['total'] : 0;

// Ambil log aktivitas terbaru
$log = $koneksi->query("
    SELECT u.nama, l.aktivitas, l.waktu
    FROM log_aktivitas l
    JOIN users u ON l.id_user = u.id_user
    ORDER BY l.waktu DESC
    LIMIT 10
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Petugas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="site-layout">
  <aside class="site-sidebar">
    <div class="brand">
        <div class="logo">SP</div>
        <div class="brand-text">
            <span>Sistem Peminjaman</span>
            <small>Asset management</small>
        </div>
    </div>
    <h2>Petugas Panel</h2>
    <a href="../petugas/approvepeminjaman.php">Approve Peminjaman</a>
    <a href="../petugas/detailpeminjaman.php">Detail Peminjaman</a>
    <a href="../petugas/pengembalian.php">Pengembalian</a>
    <a href="../login/logout.php" class="logout">Logout</a>
  </aside>

  <main class="main-content">
    <header>
        <h1>Dashboard Petugas</h1>
        <div class="welcome">Selamat datang, <strong><?= htmlspecialchars($_SESSION['nama']); ?></strong></div>
    </header>

    <div class="cards">
        <a href="../petugas/approvepeminjaman.php">
            <div class="card">
                <h2><?= $total_pending ?></h2>
                <p>Peminjaman Pending</p>
            </div>
        </a>
        <a href="../petugas/detailpeminjaman.php">
            <div class="card">
                <h2><?= $total_approved ?></h2>
                <p>Peminjaman Approved</p>
            </div>
        </a>
        <a href="../petugas/pengembalian.php">
            <div class="card">
                <h2><?= $total_pengembalian ?></h2>
                <p>Total Pengembalian</p>
            </div>
        </a>
    </div>

    <h2>Log Aktivitas Terbaru</h2>
    <table>
    <tr>
        <th>Nomor</th>
        <th>User</th>
        <th>Aktivitas</th>
        <th>Waktu</th>
    </tr>
    <?php $no=1; while($row=$log->fetch_assoc()): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= htmlspecialchars($row['aktivitas']) ?></td>
        <td><?= $row['waktu'] ?></td>
    </tr>
    <?php endwhile; ?>
    </table>
  </main>
</div>
</body>
</html>
