<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role']!='petugas'){
    header("Location: ../login/login.php");
    exit;
}
?>
<h1>KontrolPetugas <?= $_SESSION['nama']; ?></h1>
<a href="../login/logout.php">Logout</a>
