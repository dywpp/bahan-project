<?php
session_start();
if(!isset($_SESSION['id_user'])){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

$user_id = $_SESSION['id_user'];

// Hitung total peminjaman user
$total_peminjaman = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman WHERE id_user='$user_id'")) ? $result->fetch_assoc()['total'] : 0;

// Ambil data peminjaman untuk tabel
$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page-1) * $limit;
$keyword = $_GET['q'] ?? '';

$q = mysqli_query($koneksi,"
  SELECT id_peminjaman, tgl_pinjam, status
  FROM peminjaman
  WHERE id_user='$user_id' AND id_peminjaman LIKE '%$keyword%'
  ORDER BY id_peminjaman DESC
  LIMIT $start, $limit
");

$total_result = mysqli_query($koneksi,"
  SELECT COUNT(*) as total
  FROM peminjaman
  WHERE id_user='$user_id' AND id_peminjaman LIKE '%$keyword%'
");
$total = mysqli_fetch_assoc($total_result)['total'];
$pages = ceil($total / $limit);
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Peminjaman</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Reset & Base */
body{
    font-family:'Montserrat',sans-serif;
    background:#f5f2ec;
    color:#333;
    margin:0;
}
.container{
    display:flex;
    max-width:1200px;
    margin:auto;
    min-height:100vh;
}
/* Sidebar */
.sidebar{
    width:220px;
    background:#4a3f35;
    color:#fff;
    padding:20px;
}
.sidebar h2{margin-top:0;font-size:20px;}
.sidebar a{
    display:block;
    color:#fff;
    text-decoration:none;
    padding:10px;
    margin:8px 0;
    border-radius:6px;
    transition:0.3s;
}
.sidebar a:hover{background:#5f8cff;}

/* Main */
.main{
    flex:1;
    padding:20px;
}

/* Cards */
.cards{
    display:flex;
    gap:20px;
    margin-bottom:30px;
}
.card{
    flex:1;
    background:#fff;
    padding:20px;
    border-radius:12px;
    box-shadow:0 6px 15px rgba(0,0,0,0.1);
    text-align:center;
    transition:0.3s;
}
.card:hover{
    transform:translateY(-5px);
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}
.card h2{font-size:2rem;margin:0;color:#4a3f35;}
.card p{margin:5px 0 0;font-size:14px;color:#666;}

/* Table */
.panel{
    background:#fff;
    padding:20px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.05);
    margin-bottom:30px;
}
table{
    width:100%;
    border-collapse:collapse;
}
th,td{
    padding:12px;
    text-align:left;
    border-bottom:1px solid #ddd;
}
th{
    background:#f0e6d2;
    color:#4a3f35;
}
tr:hover{background:#faf5f0;}
form input{
    padding:8px;
    border-radius:6px;
    border:1px solid #ccc;
    margin-right:6px;
}
form button{
    padding:8px 12px;
    border:none;
    border-radius:6px;
    background:#5f8cff;
    color:#fff;
    cursor:pointer;
}

/* Responsive */
@media(max-width:768px){
    .container{flex-direction:column;}
    .cards{flex-direction:column;}
}
</style>
</head>
<body>

<div class="container">
    <div class="sidebar">
        <h2>Dashboard User</h2>
        <a href="user_dashboard.php">Home</a>
        <a href="user_dashboard.php">Melihat Daftar Alat</a>
        <a href="user_dashboard.php">Mengajukan Peminjaman</a>
        <a href="../transaksi/pinjam.php">Peminjaman</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main">
        <h1>Peminjaman Saya</h1>

        <!-- Cards -->
        <div class="cards">
            <div class="card">
                <h2><?= $total_peminjaman ?></h2>
                <p>Total Peminjaman</p>
            </div>
        </div>

        <!-- Form Cari -->
        <div class="panel">
            <form method="GET" action="">
                <input type="text" name="q" placeholder="Cari ID peminjaman" value="<?= htmlspecialchars($keyword) ?>">
                <button type="submit">Cari</button>
            </form>
        </div>

        <!-- Tabel -->
        <div class="panel">
            <table>
                <tr>
                    <th>#</th>
                    <th>ID Peminjaman</th>
                    <th>Tanggal Pinjam</th>
                    <th>Status</th>
                </tr>
                <?php $no = $start + 1; while($r = mysqli_fetch_assoc($q)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($r['id_peminjaman']) ?></td>
                    <td><?= htmlspecialchars($r['tgl_pinjam'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($r['status'] ?? '-') ?></td>
                </tr>
                <?php endwhile; ?>
            </table>

            <!-- Pagination -->
            <div style="margin-top:10px;">
            <?php for($i=1; $i<=$pages; $i++): ?>
                <a href="?page=<?= $i ?><?= ($keyword) ? '&q='.$keyword : '' ?>" style="margin-right:5px;"><?= $i ?></a>
            <?php endfor; ?>
            </div>
        </div>

    </div>
</div>

</body>
</html>
