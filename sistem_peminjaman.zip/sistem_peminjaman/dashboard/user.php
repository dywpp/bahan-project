<?php
session_start();
if(!isset($_SESSION['id_user'])){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

$user_id = $_SESSION['id_user'];

// Hitung total peminjaman user
$total_peminjaman = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman WHERE id_user='$user_id'")) ? $result->fetch_assoc()['total'] : 0;
$total_pending = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman WHERE id_user='$user_id' AND status='pending'")) ? $result->fetch_assoc()['total'] : 0;
$total_approved = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman WHERE id_user='$user_id' AND status='approved'")) ? $result->fetch_assoc()['total'] : 0;

// Ambil data peminjaman untuk tabel
$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page-1) * $limit;
$keyword = $_GET['q'] ?? '';

$q = mysqli_query($koneksi,"
  SELECT id_peminjaman, tgl_pinjam, status
  FROM peminjaman
  WHERE id_user='$user_id' AND id_peminjaman LIKE '%$keyword%'
  ORDER BY id_peminjaman DESC
  LIMIT $start, $limit
");

$total_result = mysqli_query($koneksi,"
  SELECT COUNT(*) as total
  FROM peminjaman
  WHERE id_user='$user_id' AND id_peminjaman LIKE '%$keyword%'
");
$total = mysqli_fetch_assoc($total_result)['total'];
$pages = ceil($total / $limit);
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard User</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="site-layout">
    <aside class="site-sidebar">
        <div class="brand">
            <div class="logo">SP</div>
            <div class="brand-text">
                <span>Sistem Peminjaman</span>
                <small>Asset Management</small>
            </div>
        </div>
        <h2>Dashboard User</h2>
        <a class="nav-link active" href="user.php">Beranda</a>
        <a class="nav-link" href="../data/search_barang.php">Daftar Alat</a>
        <a class="nav-link" href="../user/ajukan_peminjaman.php">Ajukan Peminjaman</a>
        <a class="nav-link" href="../transaksi/pinjam.php">Peminjaman</a>
        <a class="nav-link logout" href="../login/logout.php">Logout</a>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div class="title-group">
                <h1>Halo, <?= htmlspecialchars($_SESSION['nama']); ?></h1>
                <p>Kelola peminjamanmu, cek status terbaru, dan ajukan barang baru secara cepat.</p>
            </div>
            <div class="actions">
                <a class="btn btn-secondary" href="../data/search_barang.php">Cari Alat</a>
                <a class="btn btn-primary" href="../user/ajukan_peminjaman.php">Ajukan Peminjaman</a>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h2><?= $total_peminjaman ?></h2>
                <p>Total Peminjaman</p>
            </div>
            <div class="stat-card">
                <h2><?= $total_pending ?></h2>
                <p>Peminjaman Pending</p>
            </div>
            <div class="stat-card">
                <h2><?= $total_approved ?></h2>
                <p>Peminjaman Approved</p>
            </div>
        </div>

        <section class="search-card">
            <form class="search-form" method="GET" action="">
                <input class="search-input" type="text" name="q" placeholder="Cari ID peminjaman" value="<?= htmlspecialchars($keyword) ?>">
                <button class="search-button" type="submit">Cari</button>
            </form>
        </section>

        <section class="table-card">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>ID Peminjaman</th>
                            <th>Tanggal Pinjam</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = $start + 1; while($r = mysqli_fetch_assoc($q)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($r['id_peminjaman']) ?></td>
                            <td><?= htmlspecialchars($r['tgl_pinjam'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($r['status'] ?? '-') ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination">
                <?php for($i=1; $i<=$pages; $i++): ?>
                    <a class="page-link<?= $i === $page ? ' active' : '' ?>" href="?page=<?= $i ?><?= ($keyword) ? '&q='.$keyword : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        </section>
    </main>
</div>

</body>
</html>
