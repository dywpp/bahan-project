<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

// Hitung total data
$total_user = ($result=$koneksi->query("SELECT COUNT(*) as total FROM users WHERE role='user'")) ? $result->fetch_assoc()['total'] : 0;
$total_alat = ($result=$koneksi->query("SELECT COUNT(*) as total FROM alat")) ? $result->fetch_assoc()['total'] : 0;
$total_kategori = ($result=$koneksi->query("SELECT COUNT(*) as total FROM kategori")) ? $result->fetch_assoc()['total'] : 0;
$total_peminjaman = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman")) ? $result->fetch_assoc()['total'] : 0;
$total_pengembalian = ($result=$koneksi->query("SELECT COUNT(*) as total FROM pengembalian")) ? $result->fetch_assoc()['total'] : 0;

// Ambil log aktivitas terbaru
$log = $koneksi->query("
    SELECT u.nama, l.aktivitas, l.waktu
    FROM log_aktivitas l
    JOIN users u ON l.id_user = u.id_user
    ORDER BY l.waktu DESC
    LIMIT 10
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Reset & Base */
body {
    font-family: 'Montserrat', sans-serif;
    margin:0;
    background:#f5f2ec;
    display:flex;
}

/* Sidebar */
.sidebar {
    width: 220px;
    background: #4a3f35;
    color:#fff;
    height:100vh;
    display:flex;
    flex-direction:column;
    position: fixed;
}
.sidebar h2 {
    text-align:center;
    padding:20px 0;
    font-size:22px;
    border-bottom:1px solid rgba(255,255,255,0.2);
}
.sidebar a {
    color:#fff;
    text-decoration:none;
    padding:15px 20px;
    display:block;
    transition:0.2s;
}
.sidebar a:hover {
    background:#a67c52;
    color:#fff;
}
.sidebar .logout {
    margin-top:auto;
    background:#8b5e3c;
    text-align:center;
}

/* Main content */
.main {
    margin-left:220px;
    padding:30px 20px;
    flex:1;
}
header {
    margin-bottom:30px;
}
header h1{
    font-size:28px;
    color:#4a3f35;
}
header .welcome{
    font-size:16px;
    color:#4a3f35;
    margin-top:5px;
}

/* Cards */
.cards{
    display:flex;
    flex-wrap:wrap;
    gap:30px;
    margin-bottom:40px;
}
.card{
    flex:1;
    min-width:180px;
    background:#fff;
    border-radius:15px;
    padding:25px;
    box-shadow:0 6px 15px rgba(0,0,0,0.1);
    text-align:center;
    transition:0.3s;
    cursor:pointer;
}
.card:hover{
    transform:translateY(-5px);
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}
.card h2{
    font-size:2.2rem;
    margin-bottom:10px;
    color:#6b4c3b;
}
.card p{
    font-size:1rem;
    color:#666;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 4px 12px rgba(0,0,0,0.05);
}
th,td{
    padding:14px 16px;
    text-align:left;
}
th{
    background:#f0e6d2;
    color:#4a3f35;
}
tr:nth-child(even){
    background:#faf5f0;
}
tr:hover{
    background:#f0e6d2;
}

/* Responsive */
@media(max-width:768px){
    body{flex-direction:column;}
    .sidebar{width:100%; height:auto; flex-direction:row; overflow-x:auto;}
    .sidebar a{flex:1; text-align:center; padding:10px;}
    .main{margin-left:0;}
    .cards{flex-direction:column;}
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="admin_crud_user.php">Data User</a>
    <a href="admin_crud_alat.php">Alat</a>
    <a href="../admin/kategori.php">Kategori</a>
    <a href="../admin/peminjaman.php" class="peminjaman.php">Peminjaman</a>
    <a href="admin_crud_pengembalian.php">Pengembalian</a>
    <a href="login/logout.php" class="logout">Logout</a>
</div>

<div class="main">
    <header>
        <h1>Dashboard Admin</h1>
        <div class="welcome">Selamat datang, <strong><?= htmlspecialchars($_SESSION['nama']); ?></strong></div>
    </header>

    <div class="cards">
        <a href="admin_crud_user.php" style="text-decoration:none;">
            <div class="card">
                <h2><?= $total_user ?></h2>
                <p>Total User</p>
            </div>
        </a>
        <a href="admin_crud_alat.php" style="text-decoration:none;">
            <div class="card">
                <h2><?= $total_alat ?></h2>
                <p>Total Alat</p>
            </div>
        </a>
        <a href="admin_crud_kategori.php" style="text-decoration:none;">
            <div class="card">
                <h2><?= $total_kategori ?></h2>
                <p>Total Kategori</p>
            </div>
        </a>
        <a href="admin_crud_peminjaman.php" style="text-decoration:none;">
            <div class="card">
                <h2><?= $total_peminjaman ?></h2>
                <p>Total Peminjaman</p>
            </div>
        </a>
        <a href="admin_crud_pengembalian.php" style="text-decoration:none;">
            <div class="card">
                <h2><?= $total_pengembalian ?></h2>
                <p>Total Pengembalian</p>
            </div>
        </a>
    </div>

    <h2>Log Aktivitas Terbaru</h2>
    <table>
    <tr>
        <th>Nomor</th>
        <th>User</th>
        <th>Aktivitas</th>
        <th>Waktu</th>
    </tr>
    <?php $no=1; while($row=$log->fetch_assoc()): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= htmlspecialchars($row['aktivitas']) ?></td>
        <td><?= $row['waktu'] ?></td>
    </tr>
    <?php endwhile; ?>
    </table>

</div>
</body>
</html>
