<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

// Hitung total data
$total_user = ($result=$koneksi->query("SELECT COUNT(*) as total FROM users WHERE role='user'")) ? $result->fetch_assoc()['total'] : 0;
$total_alat = ($result=$koneksi->query("SELECT COUNT(*) as total FROM alat")) ? $result->fetch_assoc()['total'] : 0;
$total_kategori = ($result=$koneksi->query("SELECT COUNT(*) as total FROM kategori")) ? $result->fetch_assoc()['total'] : 0;
$total_peminjaman = ($result=$koneksi->query("SELECT COUNT(*) as total FROM peminjaman")) ? $result->fetch_assoc()['total'] : 0;
$total_pengembalian = ($result=$koneksi->query("SELECT COUNT(*) as total FROM pengembalian")) ? $result->fetch_assoc()['total'] : 0;

// Ambil log aktivitas terbaru
$log = $koneksi->query("
    SELECT u.nama, l.aktivitas, l.waktu
    FROM log_aktivitas l
    JOIN users u ON l.id_user = u.id_user
    ORDER BY l.waktu DESC
    LIMIT 10
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="site-layout">
  <aside class="site-sidebar">
    <div class="brand">
        <div class="logo">SP</div>
        <div class="brand-text">
            <span>Sistem Peminjaman</span>
            <small>Asset management</small>
        </div>
    </div>
    <h2>Admin Panel</h2>
    <a href="#">Data User</a>
    <a href="../data/barang.php">Alat</a>
    <a href="../admin/kategori.php">Kategori</a>
    <a href="../admin/peminjaman.php">Peminjaman</a>
    <a href="../laporan/riwayatpengembalian.php">Pengembalian</a>
    <a href="../login/logout.php" class="logout">Logout</a>
  </aside>

  <main class="main-content">
    <header>
        <h1>Dashboard Admin</h1>
        <div class="welcome">Selamat datang, <strong><?= htmlspecialchars($_SESSION['nama']); ?></strong></div>
    </header>

    <div class="cards">
        <div class="card">
            <h2><?= $total_user ?></h2>
            <p>Total User</p>
        </div>
        <a href="../data/barang.php">
            <div class="card">
                <h2><?= $total_alat ?></h2>
                <p>Total Alat</p>
            </div>
        </a>
        <a href="../admin/kategori.php">
            <div class="card">
                <h2><?= $total_kategori ?></h2>
                <p>Total Kategori</p>
            </div>
        </a>
        <a href="../admin/peminjaman.php">
            <div class="card">
                <h2><?= $total_peminjaman ?></h2>
                <p>Total Peminjaman</p>
            </div>
        </a>
        <a href="../laporan/riwayatpengembalian.php">
            <div class="card">
                <h2><?= $total_pengembalian ?></h2>
                <p>Total Pengembalian</p>
            </div>
        </a>
    </div>

    <h2>Log Aktivitas Terbaru</h2>
    <table>
    <tr>
        <th>Nomor</th>
        <th>User</th>
        <th>Aktivitas</th>
        <th>Waktu</th>
    </tr>
    <?php $no=1; while($row=$log->fetch_assoc()): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= htmlspecialchars($row['aktivitas']) ?></td>
        <td><?= $row['waktu'] ?></td>
    </tr>
    <?php endwhile; ?>
    </table>
  </main>
</div>
</body>
</html>
