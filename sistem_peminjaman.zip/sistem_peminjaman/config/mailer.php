<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/koneksi.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . "/PHPMailer/Exception.php";
require __DIR__ . "/PHPMailer/PHPMailer.php";
require __DIR__ . "/PHPMailer/SMTP.php";

/**
 * Kirim OTP ke user dengan pesan lengkap
 */
function sendOTP($to, $otp, $nama = 'User'){
    $mail = new PHPMailer(true);

    try {
        // ================= SMTP CONFIG =================
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'akungabutt85@gmail.com';
        $mail->Password   = 'zyycfxwqirtajakv'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->SMTPDebug  = 0; 

          $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'desmonsinaga417@gmail.com';
        $mail->Password   = 'myueywcyxclnqayc'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->SMTPDebug  = 0; 

        // ================= SENDER =================
        $mail->setFrom('speminjaman@gmail.com', 'Sistem Peminjaman');
        $mail->addAddress($to, $nama);

        // ================= CONTENT =================
        $mail->isHTML(true);
        $mail->Subject = 'Kode OTP Verifikasi Akun';

        $mail->Body = "
        <div style='font-family:Arial; background:#f4f6f9; padding:20px'>
            <div style='max-width:500px; margin:auto; background:#fff; padding:25px; border-radius:8px'>
                <h2 style='color:#222'>Halo, $nama</h2>
                <p>Kamu baru saja mendaftar di <b>Sistem Peminjaman Barang</b>.</p>
                <p>Gunakan kode OTP berikut untuk verifikasi akunmu:</p>
                <div style='text-align:center; margin:20px 0'>
                    <span style='font-size:32px; letter-spacing:6px; font-weight:bold;'>$otp</span>
                </div>
                <p><b>Catatan:</b> OTP berlaku 5 menit. Jangan bagikan kode ini ke siapapun.</p>
                <p>Jika kamu tidak mendaftar, abaikan email ini.</p>
                <hr>
                <small style='color:#666'>Sistem Peminjaman Barang © ".date('Y')."</small>
            </div>
        </div>
        ";

        $mail->send();
        return true;

    } catch (Exception $e) {
        echo "Mailer Error: " . $mail->ErrorInfo;
        return false;
    }
}

// ================= REGISTER USER =================
if(isset($_POST['register'])){
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // generate OTP
    $otp = rand(100000,999999);
    $otp_expiry = date('Y-m-d H:i:s', strtotime('+5 minutes')); // OTP 5 menit

    // simpan user inactive + OTP
    $stmt = $koneksi->prepare("INSERT INTO users (nama,email,password,otp,otp_expiry) VALUES (?,?,?,?,?)");
    $stmt->bind_param("sssss",$nama,$email,$password,$otp,$otp_expiry);

    if($stmt->execute()){
        // kirim OTP via PHPMailer
        if(sendOTP($email, $nama, $otp)){
            $_SESSION['email_verifikasi'] = $email;
            echo "Register berhasil! Cek email untuk OTP.";
        } else {
            echo "Register berhasil, tapi gagal kirim email OTP!";
        }
    } else {
        echo "Gagal register!";
    }
}
?>
