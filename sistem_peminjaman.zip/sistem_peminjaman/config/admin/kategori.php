<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

// TAMBAH KATEGORI
if(isset($_POST['tambah'])){
    $nama = $_POST['nama_kategori'];
    $kode = $_POST['kode_kategori'];
    if($nama && $kode){
        mysqli_query($koneksi,"INSERT INTO kategori (nama_kategori,kode_kategori) VALUES ('$nama','$kode')");
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    }
}

// EDIT KATEGORI
if(isset($_POST['edit'])){
    $id = $_POST['id_kategori'];
    $nama = $_POST['nama_kategori'];
    $kode = $_POST['kode_kategori'];
    mysqli_query($koneksi,"UPDATE kategori SET nama_kategori='$nama', kode_kategori='$kode' WHERE id_kategori='$id'");
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// HAPUS KATEGORI
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    mysqli_query($koneksi,"DELETE FROM kategori WHERE id_kategori='$id'");
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// AMBIL DATA
$kategori = mysqli_query($koneksi,"SELECT * FROM kategori ORDER BY id_kategori DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CRUD Kategori</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="sidebar">
    <h2>Admin Menu</h2>
    <a href="admin_crud_user.php">Data User</a>
    <a href="admin_crud_alat.php">Alat</a>
    <a href="kategori.php">Kategori</a>
    <a href="peminjaman.php">Peminjaman</a>
    <a href="admin_crud_pengembalian.php">Pengembalian</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">
    <h1>Kategori Barang</h1>

    <!-- FORM TAMBAH -->
    <div class="panel">
        <form method="post" class="form-grid">
            <input type="text" name="nama_kategori" placeholder="Nama Kategori" required>
            <input type="text" name="kode_kategori" placeholder="Kode Kategori" required>
            <button class="btn" name="tambah">+ Tambah</button>
        </form>
    </div>

    <!-- TABEL DATA -->
    <div class="panel">
        <table>
            <tr>
                <th>#</th>
                <th>Nama Kategori</th>
                <th>Kode</th>
                <th>Aksi</th>
            </tr>
            <?php $no=1; while($row=mysqli_fetch_assoc($kategori)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                <td><?= htmlspecialchars($row['kode_kategori']) ?></td>
                <td class="act">
                    <a href="#" class="edit" onclick="document.getElementById('edit<?= $row['id_kategori'] ?>').style.display='block'">Edit</a>
                    <a href="?hapus=<?= $row['id_kategori'] ?>" class="del" onclick="return confirm('Hapus kategori ini?')">Hapus</a>

                    <div id="edit<?= $row['id_kategori'] ?>" class="edit-form" style="display:none;">
                        <form method="post" class="form-grid">
                            <input type="hidden" name="id_kategori" value="<?= $row['id_kategori'] ?>">
                            <input type="text" name="nama_kategori" value="<?= htmlspecialchars($row['nama_kategori']) ?>" required>
                            <input type="text" name="kode_kategori" value="<?= htmlspecialchars($row['kode_kategori']) ?>" required>
                            <button class="btn" name="edit">Simpan</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

</body>
</html>


