<?php
session_start();
if(!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login/login.php");
    exit;
}
include "../config/koneksi.php";

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page-1) * $limit;

$keyword = $_GET['q'] ?? '';

$q = mysqli_query($koneksi,"
  SELECT p.id_peminjaman, p.tgl_pinjam, p.status, u.nama
  FROM peminjaman p
  JOIN users u ON p.id_user=u.id_user
  WHERE u.nama LIKE '%$keyword%'
  ORDER BY p.id_peminjaman DESC
  LIMIT $start, $limit
");

$total_result = mysqli_query($koneksi,"
  SELECT COUNT(*) as total
  FROM peminjaman p
  JOIN users u ON p.id_user=u.id_user
  WHERE u.nama LIKE '%$keyword%'
");
$total = mysqli_fetch_assoc($total_result)['total'];
$pages = ceil($total / $limit);
?>

<!DOCTYPE html>
<html>
<head>
<title>Peminjaman</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="sidebar">
    <h2>Admin Dashboard</h2>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="admin_crud_user.php">User</a>
    <a href="admin_crud_alat.php">Alat</a>
    <a href="kategori.php">Kategori</a>
    <a href="peminjaman.php">Peminjaman</a>
    <a href="admin_crud_pengembalian.php">Pengembalian</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">
<h1>Peminjaman</h1>

<!-- FORM CARI -->
<div class="panel">
<form method="GET" action="">
<input type="text" name="q" placeholder="Cari nama user" value="<?= htmlspecialchars($keyword) ?>">
<button type="submit">Cari</button>
</form>
</div>

<!-- TABEL -->
<div class="panel">
<table>
<tr>
<th>#</th>
<th>Peminjam</th>
<th>Tanggal Pinjam</th>
<th>Status</th>
</tr>
<?php $no = $start + 1; while($r = mysqli_fetch_assoc($q)): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= htmlspecialchars($r['nama']) ?></td>
<td><?= htmlspecialchars($r['tgl_pinjam'] ?? '-') ?></td>
<td><?= htmlspecialchars($r['status'] ?? '-') ?></td>
</tr>
<?php endwhile; ?>
</table>

<!-- PAGINASI -->
<div class="pagination">
<?php for($i=1; $i<=$pages; $i++): ?>
    <a href="?page=<?= $i ?><?= ($keyword) ? '&q='.$keyword : '' ?>" class="page-link"><?= $i ?></a>
<?php endfor; ?>
</div>

</div>
</body>
</html>
