<?php
$koneksi = new mysqli("localhost","root","","sistem_peminjaman"); // ganti nama db sesuai
if($koneksi->connect_error){
    die("Koneksi gagal: ".$koneksi->connect_error);
}
?>
