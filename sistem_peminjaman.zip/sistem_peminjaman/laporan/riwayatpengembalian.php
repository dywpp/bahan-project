<?php
include __DIR__ . '/../config/koneksi.php';

$q = mysqli_query($koneksi, "
    SELECT 
        p.id_peminjaman,
        p.tanggal_pinjam,
        p.status,
        b.nama_barang,
        d.jumlah
    FROM peminjaman p
    JOIN detail_peminjaman d ON p.id_peminjaman = d.id_peminjaman
    JOIN barang b ON d.id_barang = b.id_barang
    WHERE p.status = 'kembali'
    ORDER BY p.id_peminjaman DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Pengembalian</title>
<style>
body{
    margin:0;
    font-family: 'Segoe UI', sans-serif;
    background:#0e1014;
    color:#eaeaea;
}
.container{
    max-width:1000px;
    margin:40px auto;
    background:#141820;
    padding:25px;
    border-radius:12px;
}
.badge{
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
    background:#22c55e;
    color:#000;
}
table{width:100%;border-collapse:collapse;}
th{background:#1c2230;padding:12px;text-align:left;}
td{padding:12px;border-bottom:1px solid #232a3a;}
tr:hover{background:#1a2030;}
</style>
</head>
<body>

<div class="container">
<h2>Riwayat Pengembalian</h2>
<p>Data barang yang sudah dikembalikan</p>

<table>
<tr>
    <th>ID</th>
    <th>Tanggal</th>
    <th>Barang</th>
    <th>Jumlah</th>
    <th>Status</th>
</tr>

<?php while($r = mysqli_fetch_assoc($q)){ ?>
<tr>
    <td><?= $r['id_peminjaman'] ?></td>
    <td><?= $r['tanggal_pinjam'] ?></td>
    <td><?= $r['nama_barang'] ?></td>
    <td><?= $r['jumlah'] ?></td>
    <td><span class="badge">Kembali</span></td>
</tr>
<?php } ?>

</table>
</div>

</body>
</html>
