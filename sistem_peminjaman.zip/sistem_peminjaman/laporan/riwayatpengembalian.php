<?php
include __DIR__ . '/../config/koneksi.php';

$q = mysqli_query($koneksi, "
    SELECT 
        p.id_peminjaman,
        p.tanggal_pinjam,
        p.status,
        b.nama_barang,
        d.jumlah
    FROM peminjaman p
    JOIN detail_peminjaman d ON p.id_peminjaman = d.id_peminjaman
    JOIN barang b ON d.id_barang = b.id_barang
    WHERE p.status = 'kembali'
    ORDER BY p.id_peminjaman DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Pengembalian</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="site-layout">
    <div class="main-content">
        <div class="panel">
            <div class="panel-header">
                <h2>Riwayat Pengembalian</h2>
            </div>
            <div class="panel-body">
                <p class="text-muted">Data barang yang sudah dikembalikan</p>

                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>Barang</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($r = mysqli_fetch_assoc($q)){ ?>
                        <tr>
                            <td><?= $r['id_peminjaman'] ?></td>
                            <td><?= $r['tanggal_pinjam'] ?></td>
                            <td><?= $r['nama_barang'] ?></td>
                            <td><?= $r['jumlah'] ?></td>
                            <td><span class="badge badge-success">Kembali</span></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>
