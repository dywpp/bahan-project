TYPE=VIEW
query=select `u`.`id_user` AS `id_user`,`u`.`nama` AS `nama`,ifnull(sum(`p`.`denda`),0) AS `total_denda` from (`sistem_peminjaman`.`users` `u` left join `sistem_peminjaman`.`peminjaman` `p` on(`u`.`id_user` = `p`.`id_user`)) group by `u`.`id_user`
md5=50f8670303d695df4dc1822b0ce4fb2e
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001770695127802463
create-version=2
source=SELECT \n  u.id_user,\n  u.nama,\n  IFNULL(SUM(p.denda),0) AS total_denda\nFROM users u\nLEFT JOIN peminjaman p ON u.id_user = p.id_user\nGROUP BY u.id_user
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_unicode_ci
view_body_utf8=select `u`.`id_user` AS `id_user`,`u`.`nama` AS `nama`,ifnull(sum(`p`.`denda`),0) AS `total_denda` from (`sistem_peminjaman`.`users` `u` left join `sistem_peminjaman`.`peminjaman` `p` on(`u`.`id_user` = `p`.`id_user`)) group by `u`.`id_user`
mariadb-version=100432
