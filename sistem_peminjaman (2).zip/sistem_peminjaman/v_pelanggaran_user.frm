TYPE=VIEW
query=select `u`.`id_user` AS `id_user`,`u`.`nama` AS `nama`,count(case when `p`.`denda` > 0 then 1 end) AS `total_telat`,ifnull(sum(`p`.`denda`),0) AS `total_denda` from (`sistem_peminjaman`.`users` `u` left join `sistem_peminjaman`.`peminjaman` `p` on(`u`.`id_user` = `p`.`id_user`)) group by `u`.`id_user`
md5=33ad8a3cb8e4e3761dabea1c34d54a4f
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001770694964100401
create-version=2
source=SELECT \n  u.id_user,\n  u.nama,\n  COUNT(CASE WHEN p.denda > 0 THEN 1 END) AS total_telat,\n  IFNULL(SUM(p.denda),0) AS total_denda\nFROM users u\nLEFT JOIN peminjaman p ON u.id_user = p.id_user\nGROUP BY u.id_user
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_unicode_ci
view_body_utf8=select `u`.`id_user` AS `id_user`,`u`.`nama` AS `nama`,count(case when `p`.`denda` > 0 then 1 end) AS `total_telat`,ifnull(sum(`p`.`denda`),0) AS `total_denda` from (`sistem_peminjaman`.`users` `u` left join `sistem_peminjaman`.`peminjaman` `p` on(`u`.`id_user` = `p`.`id_user`)) group by `u`.`id_user`
mariadb-version=100432
